This folder contains an example custom user storage provider that is used to help test the `keycloak_custom_user_federation` resource.

You can build this provider by running `./gradlew shadowJar`, or by running `make user-federation-example` from the root directory.
